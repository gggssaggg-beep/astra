const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-lICrT2gk.js","./index-CX8FdaNM.js","./index-DPn77Axq.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CX8FdaNM.js";const _=r("Share",{web:()=>t(()=>import("./web-lICrT2gk.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
