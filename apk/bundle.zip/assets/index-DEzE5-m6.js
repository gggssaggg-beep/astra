const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-Hz4-41Ub.js","./index-S5KtPX3j.js","./index-DW1OGCwX.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-S5KtPX3j.js";const _=r("Share",{web:()=>t(()=>import("./web-Hz4-41Ub.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
