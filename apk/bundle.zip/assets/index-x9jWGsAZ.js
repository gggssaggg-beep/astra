const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-Dwh7F2Z-.js","./index-DecEJWmN.js","./index-CuRLdMXp.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-DecEJWmN.js";const _=r("Share",{web:()=>t(()=>import("./web-Dwh7F2Z-.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
