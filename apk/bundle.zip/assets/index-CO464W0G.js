const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-gMK-h2v6.js","./index-YhYHPRn5.js","./index-DOoz9mHd.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-YhYHPRn5.js";const _=r("Share",{web:()=>t(()=>import("./web-gMK-h2v6.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
