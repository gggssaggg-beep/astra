const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-BGYTBrVv.js","./index-DxDAkQVi.js","./index-BZVntLng.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-DxDAkQVi.js";const _=r("Share",{web:()=>t(()=>import("./web-BGYTBrVv.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
