const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-0jNrkUT9.js","./index-DHV-V-Sr.js","./index-CQG0r_sy.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-DHV-V-Sr.js";const _=r("Share",{web:()=>t(()=>import("./web-0jNrkUT9.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
