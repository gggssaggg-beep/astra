const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-CCc60XYy.js","./index-Dr4fOwUn.js","./index-6xJ4e3ZY.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-Dr4fOwUn.js";const _=r("Share",{web:()=>t(()=>import("./web-CCc60XYy.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
