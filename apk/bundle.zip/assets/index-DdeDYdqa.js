const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-DHg0wK_0.js","./index-B-GYbbpU.js","./index-BnLXljPH.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-B-GYbbpU.js";const _=r("Share",{web:()=>t(()=>import("./web-DHg0wK_0.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
