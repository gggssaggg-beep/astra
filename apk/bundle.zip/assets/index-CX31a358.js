const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-OGgPiINi.js","./index-Bq4CkGLl.js","./index-DOoz9mHd.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-Bq4CkGLl.js";const _=r("Share",{web:()=>t(()=>import("./web-OGgPiINi.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
