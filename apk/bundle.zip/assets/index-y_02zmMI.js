const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-B-zrmj_w.js","./index-Ciffetwn.js","./index-DVgQKvck.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-Ciffetwn.js";const _=r("Share",{web:()=>t(()=>import("./web-B-zrmj_w.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
