const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-BHC3aWgm.js","./index--flTeO7e.js","./index-BMQ_BTPV.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index--flTeO7e.js";const _=r("Share",{web:()=>t(()=>import("./web-BHC3aWgm.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
