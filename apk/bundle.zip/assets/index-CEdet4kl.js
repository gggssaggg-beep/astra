const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-BOM0jdC-.js","./index-CmbDmSZz.js","./index-CVglRRUg.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CmbDmSZz.js";const _=r("Share",{web:()=>t(()=>import("./web-BOM0jdC-.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
