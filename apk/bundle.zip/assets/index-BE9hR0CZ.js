const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-BpVZHIl0.js","./index-DD4mBg6P.js","./index-BC0Q4UxW.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-DD4mBg6P.js";const _=r("Share",{web:()=>t(()=>import("./web-BpVZHIl0.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
