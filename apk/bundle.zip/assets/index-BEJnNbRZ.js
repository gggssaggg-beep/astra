const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-CKCo_GSe.js","./index-DiZ9punL.js","./index-DmAm9lql.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-DiZ9punL.js";const _=r("Share",{web:()=>t(()=>import("./web-CKCo_GSe.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
