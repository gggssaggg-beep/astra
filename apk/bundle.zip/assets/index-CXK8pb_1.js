const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-DspcY0X7.js","./index-ZJpuyQCq.js","./index-gpiKuJqp.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-ZJpuyQCq.js";const _=r("Share",{web:()=>t(()=>import("./web-DspcY0X7.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
