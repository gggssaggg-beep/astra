const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-D2nRce13.js","./index-CEpNNvi6.js","./index-DW1OGCwX.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CEpNNvi6.js";const _=r("Share",{web:()=>t(()=>import("./web-D2nRce13.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
