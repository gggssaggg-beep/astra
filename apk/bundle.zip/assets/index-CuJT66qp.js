const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-Oas_Zk_-.js","./index-PsxlydiL.js","./index-B7dhpNSL.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-PsxlydiL.js";const _=r("Share",{web:()=>t(()=>import("./web-Oas_Zk_-.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
