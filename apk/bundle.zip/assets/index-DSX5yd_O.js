const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-BgLA8CVx.js","./index-CntHF-em.js","./index-DTVmk4ev.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CntHF-em.js";const _=r("Share",{web:()=>t(()=>import("./web-BgLA8CVx.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
