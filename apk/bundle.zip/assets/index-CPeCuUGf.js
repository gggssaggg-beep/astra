const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-BKJTFkoo.js","./index-ByXoNg1g.js","./index-De6uxRFc.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-ByXoNg1g.js";const _=r("Share",{web:()=>t(()=>import("./web-BKJTFkoo.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
