const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-Cb51Xu2N.js","./index-B7hJ7sI9.js","./index-B9-sseab.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-B7hJ7sI9.js";const _=r("Share",{web:()=>t(()=>import("./web-Cb51Xu2N.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
