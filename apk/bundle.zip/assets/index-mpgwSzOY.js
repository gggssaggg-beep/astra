const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-B20JF9OF.js","./index-BYBkPkSD.js","./index-q54WeYZn.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-BYBkPkSD.js";const _=r("Share",{web:()=>t(()=>import("./web-B20JF9OF.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
