const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-C6ambLiR.js","./index-CqqkBo4k.js","./index-B0_PvXEt.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CqqkBo4k.js";const _=r("Share",{web:()=>t(()=>import("./web-C6ambLiR.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
