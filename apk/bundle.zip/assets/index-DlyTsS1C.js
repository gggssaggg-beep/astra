const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-Cq1KI8kk.js","./index-DhcE-8TO.js","./index-BMQ_BTPV.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-DhcE-8TO.js";const _=r("Share",{web:()=>t(()=>import("./web-Cq1KI8kk.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
